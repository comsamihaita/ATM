package ro.jademy.atm.main;

import java.util.ArrayList;
import java.util.InputMismatchException;
import java.util.Scanner;

import ro.jademy.atm.model.Register;
import ro.jademy.atm.model.User;
import ro.jademy.atm.service.Login;
import ro.jademy.atm.ui.Meniu;

public class App {

	// Datbase
	public static ArrayList<User> registeredUser;
	public static Meniu meniu;
	public static Scanner s;
	public static User currentUser;
	public static Boolean runningApp = true;
	public static final Integer EXIT = 0;
	public static int amount = 0;
	public static int amountToRemove = 0;

	public static void main(String[] args) {

		init();

		while (runningApp) {
		
			meniu.showPrincipal();
			Integer opt = meniu.readOption(s);

			switch (opt) {
			case 1:
				System.out.println("Execute login");
				Login login = new Login();

				if (login.execute(s)) {
					handlerSecundar();
				}
				break;
			case 2:
				System.out.println("Please create a new acount");
				Register register = new Register();
				register.readCredentilas(s);
				handlerSecundar();
				break;

			default:
				System.out.println("Invalid option");
				break;

			}
		}

	}

	private static void handlerSecundar() {
		Integer optS;
		do {
			meniu.showSecundar();
			optS = meniu.readOption(s);
			switch (optS) {
			case 1:
				handleShowSold();
				break;
			case 2:
				handleAdd();
				break;
			case 3:
				handleRemoveSold();
				break;
			case 4:
				System.out.println("Execute transaction:");
				App.currentUser.acountStatement();
				break;
			case 0:
				return;

			default:
				System.out.println("Invalid option");
				break;
			}
		} while (optS != EXIT);
	}

	private static void handleAdd() {
		System.out.println("Input amount of money you want to deposit: ");

		while(!s.hasNextInt()){
			System.out.println("Invalid value.Please enter a digit number.");
			 s.next();
		}

		Integer amount = s.nextInt();
			
			if ((amount == 0) || (amount < 0)) {
				System.out.println("You cannot add 0 or a value smaller then 0.");
				return;
			}
			System.out.println("Your amount will be deposited with: " + amount);
			System.out.println("If it's ok, type Y, else press any other key...");
			String option = s.next();
			if ("Y".equalsIgnoreCase(option)) {
				App.currentUser.addMoneyToAccount(amount);
			} else {
			}
			

		}


	private static void handleRemoveSold() {
		System.out.println("Input amount of money you want to witdraw:");
		System.out.println("For returning to the main menu,type EXIT!");

		Integer amountToRemove = s.nextInt();
		if ((amountToRemove == 0) || (amountToRemove < 0)) {
			System.out.println("Please enter an amount bigger then o");
			return;
		}
		if (amountToRemove > App.currentUser.getSold()) {
			System.out.println("You don't have enough money in your account");
			return;
		} else {
			System.out.println("Your account will be deducted with: " + amountToRemove);
			System.out.println("If it's ok, type Y, else press any other key...");

			String option = s.next();
			if ("Y".equalsIgnoreCase(option)) {
				App.currentUser.removeMoneyFromAccount(amountToRemove);
			} else {
			}
		}
	}

	private static void handleShowSold() {
		System.out.println("Your current balance is:");
		System.out.println(App.currentUser.getSold());
	}

	private static void init() {
		System.out.println("Init ATM....\n");
		meniu = new Meniu();
		s = new Scanner(System.in);
		registeredUser = new ArrayList<User>();
		addAdmin();
		System.out.println(registeredUser);
		System.out.println("ATM started!\n");
	}

	private static void addAdmin() {
		User u = new User();
		u.setFullname("Admin IT");
		u.setUsername("admin");
		u.setPassword("admin");
		u.setSold(10000000);
		u.getTranzactii().add(new Transactions("Sold initial", 0));
		registeredUser.add(u);
	}

}
