package ro.jademy.atm.main;

public class Transactions {
	
	private String operatiune;
	private int valuare;
	private int soldCurent;
	
	public Transactions(){
		
	}
	
	public int getSoldCurent(){
		return soldCurent;
	}
	public void setSoldCurent(int soldCurent){
		this.soldCurent = soldCurent;
	}

	public String getOperatiune() {
		return operatiune;
	}

	public void setOperatiune(String operatiune) {
		this.operatiune = operatiune;
	}

	public int getValuare() {
		return valuare;
	}

	public void setValuare(int valuare) {
		this.valuare = valuare;
	}
	public  Transactions(String operatiune, int valuare){
		
	}

	@Override
	public String toString() {
		return "Transactions [operatiune=" + operatiune + ", valuare=" + valuare + ", soldCurent=" + soldCurent + "]";
	}
	

}
