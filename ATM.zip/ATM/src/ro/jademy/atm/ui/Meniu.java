package ro.jademy.atm.ui;

import java.util.Scanner;

import ro.jademy.atm.main.App;

public class Meniu {
	
	public void showPrincipal(){
		System.out.println("Chose the number of your option: ");
		System.out.println("(1) Login");
		System.out.println("(2) Register");
	}
	
	public Integer readOption( Scanner s){
		
		String readOption = null;
		readOption = s.next();
		if(readOption.matches("\\d+")){// checks if input only conteins digids
			return Integer.parseUnsignedInt(readOption);
		}else{
			return 0;
		}
	}
	
	public void showSecundar(){
		System.out.println("Chose the number for your option:");
		System.out.println("(1) Check sold");
		System.out.println("(2) Add money");
		System.out.println("(3) Remove");
		System.out.println("(4) Tranzaction");
		System.out.println("(" + App.EXIT+") Exit");
	}

}
