package ro.jademy.atm.service;

import java.util.Scanner;

import ro.jademy.atm.main.App;
import ro.jademy.atm.model.User;

public class Login {
	public static final String CORECT_INFO = "SUCCESS";
	public static final String INCORRECT_PASS = "INCORRECT_PASS";
	public static final String INCORRECT_USER = "INCORRECT_USER";
	public static String ERROR = "ERROR";
	
	private String validateId(){
		for(User u : App.registeredUser){
			if((u.getUsername().equals(App.currentUser.getUsername()))){
				App.currentUser = u;
				return CORECT_INFO;
			}else if(true){
				System.out.println("Cont blocat momentan");
			}
		}
		return null;
	}
	
	private void readId(Scanner s){
		System.out.println("Input username: ");
		String user = s.next();
		App.currentUser = new User("" , user);
	}
	
	public boolean execute(Scanner s){
		readCredentials(s);
		String result = validate();
		feedback(result);
		return CORECT_INFO.equals(result);
	}
	
	public void readCredentials(Scanner s){
		System.out.println("Input username: ");
		String user = s.next();
		System.out.println("Input password: ");
		String pass = s.next();
		App.currentUser = new User(pass,user);
	}
	
	public String validate(){
		// Search user in registered users list
		for(User u : App.registeredUser){
			
			if(u.getUsername().equals(App.currentUser.getUsername())){
				if(u.getPassword().equals(App.currentUser.getPassword())){
					App.currentUser = u;
					return CORECT_INFO;
				}else{
					return INCORRECT_PASS;
				}
			}else{
				return INCORRECT_USER;
			}
		}
		return ERROR;
	}
	
	public void feedback(String code){
		switch(code){
		case CORECT_INFO:
			System.out.println("Welcome " + App.currentUser.getFullname());
			break;
		case INCORRECT_USER:
			System.out.println("User not found, please register!");
			break;
		case INCORRECT_PASS:
			System.out.println("Wrong password! Please try again!");
			break;
			default:
				break;
		}
	}

}
