package ro.jademy.atm.model;

import java.util.Scanner;

import ro.jademy.atm.main.App;

public class Register {
	
	public void readCredentilas(Scanner s){
		System.out.println("Input username: ");
		String user = s.next();
		System.out.println("Input password");
		String pass = s.next();
		System.out.println("Please insert your full name");
		String full = s.next();
		
		User newUser = new User(pass,user);
		newUser.setFullname(full);
		newUser.setSold(200);
		App.registeredUser.add(newUser);
		App.currentUser = newUser;
		System.out.println("Welcome, " + full + ", you have succesfully register.");
	}

}
