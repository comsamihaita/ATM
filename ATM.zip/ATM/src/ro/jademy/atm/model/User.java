package ro.jademy.atm.model;

import java.util.ArrayList;

import ro.jademy.atm.main.Transactions;

public class User {
	
	private String fullname;
	private String password;
	private String username;
	private Integer sold;
	private ArrayList<Transactions> tranzactii = new ArrayList<Transactions>();
	
	public User(){
		tranzactii = new ArrayList<Transactions>();
	}
	
	public ArrayList<Transactions> getTranzactii(){
		return tranzactii;
	}
	
	public void setTranzactii(ArrayList<Transactions> tranzactii){
		this.tranzactii = tranzactii;
	}
	public User(String password, String username){
		this.password = password;
		this.username = username;
	}
	public String getFullname(){
		return fullname;
	}
	public void setFullname(String fullname){
		this.fullname = fullname;
	}
	public String getPassword(){
		return password;
	}
	public void setPassword(String passsword){
		this.password = passsword;
	}
	public String getUsername(){
		return username;
	}
	public void setUsername(String username){
		this.username = username;
	}

	@Override
	public String toString() {
		return "User [fullname=" + fullname + ", username=" + username + "]";
	}
	
	
	public Integer getSold() {
		return sold;
	}

	public void setSold(Integer sold){
		this.sold = sold;
	}
	
	public void addMoneyToAccount(Integer amount){
		sold+=amount;
		Transactions showMoneyAdded = new Transactions();
		showMoneyAdded.setOperatiune("Money added");
		showMoneyAdded.setValuare(amount);
		showMoneyAdded.setSoldCurent(sold);
		tranzactii.add(showMoneyAdded);
	}
	
	public void removeMoneyFromAccount(Integer amountToRemove){
		sold = amountToRemove;
		Transactions showMoneyRemoved = new Transactions();
		showMoneyRemoved.setOperatiune("Money removed");
		showMoneyRemoved.setValuare(amountToRemove);
		showMoneyRemoved.setSoldCurent(sold);
		tranzactii.add(showMoneyRemoved);
		
	}
	
	public void acountStatement(){
		for(Transactions transaction : tranzactii){
			System.out.println(transaction);
		}
		
	}
}
